<style>
  body {
    margin: 0;
    padding-bottom: 60px;
    /* Height of the footer */
  }

  .footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    background-color: #333;
    color: white;
    text-align: center;
    padding: 10px 0;
  }
</style>
<div class="footer">
  <p>&copy;
    <?php echo date("Y"); ?> vrishanksoft.com. All Rights Reserved.
  </p>
</div>

</html>