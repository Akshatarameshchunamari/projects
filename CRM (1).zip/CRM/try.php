.body1 {
    display: flex;
    height: 100vh;
}

#menu {
    background: #d6cfcf;
    width: 300px;
    height: 100%;
}

#menu .logo {
    display: flex;
    align-items: center;
    color: #000000;
    padding: 20px 0 0 20px;
}

#menu .items {
    margin-top: 40px;
}

#menu .items ul {
    list-style: none;
    padding: 0px;
    margin: 20px;
}

#menu .items li {
    padding: 15px 0;
    transition: 0.3s;
}

#menu .items li:hover {
    background: #9298a8;
    cursor: pointer;
}

#menu .items li i {
    color: rgb(119, 132, 156);
    width: 30px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    font-size: 14px;
    /* margin-left: 10px; */
    margin: 0 10px 10px 25px;
}

#menu .items li:hover i,
#menu .items li:hover a {
    color: #4570d4;
}

#menu .items li a {
    text-decoration: none;
    color: rgb(4, 4, 4);
    font-weight: 300px;
    transition: 0.3s;
    padding-left: 20px;
    
}





.i-name {
    color: #15181d;
    padding: 20px 20px 0 30px;
    font-size: 24px;
    font-weight: 700;

}

.value {
    padding: 20px 20px 0 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
}

.value .valbox {
    background: #efeded;
    width: 235px;
    padding: 16px 20px;
    border-radius: 5px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
}

.value .valbox .icons {
    font-size: 35px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    text-align: center;
    color: aliceblue;
    margin-right: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.valbox.project {
    background-color: #3498db; /* Blue color for Project */
}

.valbox.investment {
    background-color: #2ecc71; /* Green color for Investment */
}

.valbox.income {
    background-color: #f39c12; /* Orange color for Income-generating */
}

.valbox.expense {
    background-color: #e74c3c; /* Red color for Expense */
}

.value .valbox h3 {
    font-size: 18px;
    font-weight: 600;
}

.value .valbox span {
    font-size: 15px;
    color: #0d0e10;
}